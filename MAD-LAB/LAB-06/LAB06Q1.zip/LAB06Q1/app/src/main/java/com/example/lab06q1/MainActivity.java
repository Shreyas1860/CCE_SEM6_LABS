package com.example.lab06q1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.lab06q1.R;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_courses) {
            displayCourseDetails();
            return true;
        } else if (id == R.id.menu_admission) {
            displayAdmissionDetails();
            return true;
        } else if (id == R.id.menu_faculty) {
            displayFacultyDetails();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }
    private void displayCourseDetails() {
        // Launch CourseDetailsActivity or display details in a fragmen
        Intent intent = new Intent(this, CoursesActivity.class);
        startActivity(intent);
    }

    private void displayAdmissionDetails() {
        Intent intent = new Intent(this, AdmissionActivity.class);
        startActivity(intent);
    }

    private void displayFacultyDetails() {
        // Launch FacultyDetailsActivity or display details in a fragment
    }
}

