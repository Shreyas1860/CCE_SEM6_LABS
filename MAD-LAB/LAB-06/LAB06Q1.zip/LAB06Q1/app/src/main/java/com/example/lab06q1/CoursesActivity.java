package com.example.lab06q1;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CoursesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        LinearLayout coursesLayout = findViewById(R.id.coursesLayout);

        String[] courses = {"Computer Science", "Data Science", "Software Engineering", "Artificial Intelligence"};

        for (String course : courses) {
            TextView courseTextView = new TextView(this);
            courseTextView.setText(course);
            courseTextView.setTextSize(24);
            coursesLayout.addView(courseTextView);
        }
    }
}
