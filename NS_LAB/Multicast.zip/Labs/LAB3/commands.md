awk -f filename.awk filename.tr

graphcode awk files, graphs, command for trace